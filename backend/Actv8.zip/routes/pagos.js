const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de los Pagos')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM pagos')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM pagos WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO pagos...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE pagos...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM pagos")
})

module.exports=router;