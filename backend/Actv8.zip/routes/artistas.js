const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de los Artistas')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM artistas')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM artistas WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO artistas...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE artistas...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM artistas")
})

module.exports=router;