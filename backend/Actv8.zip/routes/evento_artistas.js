const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de los Evento_artistas')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM evento_artistas')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM evento_artistas WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO evento_artistas...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE evento_artistas...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM evento_artistas")
})

module.exports=router;