const express = require("express");
const router = express.Router();
const mysql = require("../db/mysql");
const sqlite = require("../db/sqlite");

router.get('/',(req,res) => {
    res.send("Rutas de los Auditorios")
});

router.get('/index',(req,res) => {
    res.send("CRUD muestra todos los registros, SELECT * FROM auditorios")
});

router.get('/show',(req,res)=>{
    res.send("CRUD muestra un solo registro, SELECT * FROM auditorios WHERE...")
});

router.post('/store',(req,res)=>{
    res.send("CRUD funcion para insertar, INSERT INTO audiorios...")
});

router.put('/update',(req,res)=>{
    res.send("CRUD funcion para actualizar UPDATE auditorios...")
});

router.delete('/destroy',(req,res)=>{
    res.send("CRUD funcion para eliminar, DELETE FROM auditorios...")
})

//LEER
router.get("/leer", (req, res) => {
    mysql.query("SELECT * FROM auditorios",(err,rows) => {
        if(err) return res.status(500).json({error: "Error en MySQL"});
        res.json(rows);
    });
});


//CREATE
router.post("/crear", (req, res) => {
    const {nombre, capacidad, ubicacion} = req.body;

    //Insertar en MySQL
    mysql.query(
        "INSERT INTO auditorios (nombre, capacidad, ubicacion) VALUES (?,?,?)",
        [nombre, capacidad, ubicacion],
        (err, result) => {
            if (err) return res.status(500).json({error:"Error MySQL"});

            //Insertar en SQLite
            sqlite.run(
                "INSERT INTO auditorios(nombre, capacidad, ubicacion) VALUES (?,?,?)",
                [nombre, capacidad, ubicacion],
                (errSqlite) => {
                    if(errSqlite) console.error("Error SQLite: ", errSqlite);
                    // Respuesta final UNA sola vez
                    res.json({ok:true, id:result.insertId, msg:"Auditorio  en ambas BD"});
                }
            );
        }
    );
});


//UPDATE
router.put("/actualizar/:id",(req, res) => {
    const {id} = req.params;
    const {nombre, capacidad, ubicacion} = req.body;

    //Actualizar en MySQL
    mysql.query(
        "UPDATE auditorios SET nombre=?, capacidad=?, ubicacion=? WHERE id_auditorio=?",
        [nombre, capacidad, ubicacion, id],
        (err, result) => {
            if(err) return res.status(500).json({ error: "Error MySQL"});
        }
    );

    //Actualizar en SQLite
    sqlite.run(
        "UPDATE auditorios SET nombre=?, capacidad=?, ubicacion=? WHERE id_auditorio=?",
        [nombre, capacidad, ubicacion, id],
        (errSqlite) => {
            if(errSqlite) console.error("Error SQLite: ", errSqlite);
            res.json({ok:true, msg:"Auditorio actualizado en ambas Bases de Datos"});
        }
    );

});


// DELETE
router.delete("/eliminar/:id", (req, res) => {
  const { id } = req.params;

  // MySQL
  mysql.query(
    "DELETE FROM auditorios WHERE id_auditorio=?",
    [id],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Error MySQL" });
    }
  );

  // SQLite
  sqlite.run(
    "DELETE FROM auditorios WHERE id_auditorio=?",
    [id],
    (err) => {
      if (err) console.error("Error SQLite:", err);
    }
  );

  res.json({ ok: true, msg: "Auditorio eliminado en ambas BD" });
});

module.exports=router;