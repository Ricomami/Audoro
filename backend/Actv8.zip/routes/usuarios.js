const express = require('express');
const router = express.Router();

router.get('/',(req,res) =>{
    res.send("Rutas de los Usuarios")
});

router.get('/index',(req,res) =>{
    res.send("CRUD muestra todos los registros SELECT * FROM usuarios")
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM usuarios WHERE...')
});

router.post('/store',(req,res)=>{
    res.send("CRUD funcion para insertar, INSERT INTO usuarios...")
});

router.put('/update', (req,res)=>{
    res.send("CRUD  funcion para actualizar, UPDATE usuarios...")
})

router.delete('/destroy', (req,res)=>{
    res.send("CRUD funcion para eliminar, DELETE FROM usuarios...")
})

module.exports=router;