const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de las Secciones')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM secciones')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM secciones WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO secciones...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE secciones...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM secciones")
})

module.exports=router;