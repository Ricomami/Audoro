const express = require('express');
const routes = express.Router();

routes.get('/', (req,res) => {
    res.send("Rutas de los Asientos")
});

routes.get('/index',(req,res) => {
    res.send("CRUD muestra todos los registros, SELECT * FROM asientos")
});

routes.get('/show',(req,res) => {
    res.send("CRUD muestra un registro, SELECT * FROM asientos WHERE...")
});

routes.post('/store',(req,res) => {
    res.send("CRUD funcion para insertar, INSERT INTO asientos...")
});

routes.put('/update', (req,res) => {
    res.send("CRUD funcion para actualizar, UPDATE asientos...")
});

routes.delete('/destroy', (req, res) => {
    res.send("CRUD funcion para eliminar, DELETE FROM asientos...")
})

module.exports=routes;