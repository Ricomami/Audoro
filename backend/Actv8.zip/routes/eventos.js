const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de los Eventos')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM eventos')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM eventos WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO eventos...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE eventos...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM eventos")
})

module.exports=router;