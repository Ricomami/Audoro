const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de las Entradas')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM entradas')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM entradas WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO entradas...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE entradas...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM entradas")
})

module.exports=router;