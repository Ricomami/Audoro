const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de los Clientes')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM clientes')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM clientes WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO clientes...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE clientes...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM clientes")
})

module.exports=router;