const express = require('express');
const router = express.Router();

router.get('/',(req,res) => {
    res.send('Rutas de las Funciones')
});

router.get('/index', (req, res) => {
    res.send('CRUD muestra todos los registros SELECT * FROM funciones')
});

router.get('/show', (req,res) =>{
    res.send('CRUD muestra un registro SELECT * FROM funciones WHERE...')
});

router.post('/store', (req, res) =>[
    res.send("CRUD funcion para insertar, INSERT INTO funciones...")
]);

router.put('/update', (req, res) => {
    res.send('CRUD funcion para actualizar UPDATE funciones...')
});

router.delete('/destroy', (req, res) =>{
    res.send("CRUD funcion para eliminar, DELETE FROM funciones")
})

module.exports=router;