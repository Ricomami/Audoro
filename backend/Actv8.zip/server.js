const express = require("express");
const cors = require("cors");

const app=express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res)=>{
    res.send("Servidor backend funcionando 🚀");
});
app.listen(3000,() =>{
    console.log("Servidor corriendo en http://localhost:3000");
});

//ARTISTAS
const artistasRoutes = require("./routes/artistas")
app.use("/artistas",artistasRoutes);


// ASIENTOS
const asientosRoutes = require("./routes/asientos")
app.use("/asientos",asientosRoutes);


// CLIENTES
const clientesRoutes = require("./routes/clientes")
app.use("/clientes",clientesRoutes);


// ENTRADAS
const entradasRoutes = require("./routes/entradas")
app.use("/entradas",entradasRoutes);

//EVENTOS
const eventosRoutes= require("./routes/eventos")
app.use("/eventos", eventosRoutes);

// EVENTO_ARTISTAS
const evento_artistasRoutes = require("./routes/evento_artistas")
app.use("/evento_artistas",evento_artistasRoutes);


// FUNCIONES
const funcionesRoutes = require("./routes/funciones")
app.use("/funciones",funcionesRoutes);


// PAGOS
const pagosRoutes = require("./routes/pagos")
app.use("/pagos",pagosRoutes);


// SECCIONES
const seccionesRoutes = require("./routes/secciones")
app.use("/secciones",seccionesRoutes);


// USUARIOS
const usuariosRoutes = require("./routes/usuarios")
app.use("/usuarios",usuariosRoutes);


//AUDITORIOS
const auditoriosRoutes = require("./routes/auditorios");
app.use("/auditorios",auditoriosRoutes);
